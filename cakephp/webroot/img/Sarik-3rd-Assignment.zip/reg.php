<?php
include "conn.php";
if (isset($_POST['submit'])) {
    $FirstName = $_POST["first_name"];
    $LastName = $_POST["last_name"];
    $Email = $_POST["email"];
    $PhoneNumber = $_POST["phone"];
    $Password = $_POST["password"];
    $confirm = $_POST["confirm"];
    $gender = $_POST["gender"];
    $chk = 0;

    if (empty($FirstName)) {
        $error_fn = "* Enter First Name";
        $chk=1;

    } else {
        $FirstName;
        

    }


    if (empty($LastName)) {
        $error_ln = "* Enter Last Name";
        $chk=1;

    } else {
        $LastName;
        
    }


    if (empty($Email)) {
        $error_em = "* Enter Email";
        $chk=1;

    } else {
        $Email;
       
    }


    if (empty($PhoneNumber)) {
        $error_phone = "* Enter PhoneNumber";
        $chk=1;

    } else {
        $PhoneNumber;

    }


    if (empty($Password)) {
        $error_pass = "* Enter Password";
        $chk=1;

    } else {
        $Password;
        
    }



    if (empty($confirm)) {
        $error_confirm = "* Re-Enter Password";
        $chk=1;

    }
    if ($Password != $confirm) {
        $error_confirm = "* Confirm Password";
        $chk=1;
    } else {
        $confirm;
       
    }



    if (empty($gender)) {
        $error_gender = "* Select Gender";
        $chk=1;

    } else {
        $confirm;
       
    }


    if ($chk == 0) {

        $sql = "INSERT INTO users(first_name, last_name, email, phone_number, password , gender) VALUES ('$FirstName', '$LastName', '$Email',  '$PhoneNumber', '$Password', '$gender')";
        $result = mysqli_query($conn, $sql);
        if ($result) {
            header("Location: login.php");
         } else {
            echo "Could not insert record: " . mysqli_error($conn);
        }
    }


    mysqli_close($conn);

}
?>