<?php 
include 'conn.php';

session_start();
$email1 = $_SESSION['email'];
if ($email1 == true)
    {  
        $id=$_GET['id'];
        $query="DELETE FROM users where id='$id'";
        $data = mysqli_query($conn,$query);
    }
    else{
        header('location:login.php'); 
    }


if ($data) {
    ?>
    <script>
        alert("Data Deleted Successfully");
        window.open("http://localhost/assignment-3/display.php","_self");
    </script>
    <?php
}else{
    ?>
    <script>
        alert("Data not Deleted");
    </script>
    <?php
}


?>