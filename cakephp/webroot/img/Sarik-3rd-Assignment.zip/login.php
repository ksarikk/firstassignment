<?php
include 'conn.php';
session_start();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel="stylesheet" href="style.css">
</head>

<body style="background-color: lightcyan;">

    <br><br><br>
    <div id="login" class=" loginclass" style="border:8px solid black;margin:100px">

        <div class="container">
            <div id="login-row" class="row justify-content-center align-items-center">
                <div id="login-column" class="col-md-6">
                    <div id="login-box" class="col-md-12">
                        <br><br>
                        <form id="login-form" class="form" action="" method="post">
                            <h3 class="text-center text-info"><b><span style="font-size:45px">
                                        <marquee>L O G I N - F O R M</marquee>
                                    </span></b></h3>
                            <br>
                            <br>
                            <div class="form-group">
                                <label for="username" class="text-info"><span
                                        style="font-size:30px">Email:</span></label><br>
                                <input type="text" name="email" id="email" class="form-control"
                                    placeholder="abc@gmail.com">
                            </div>
                            <div class="form-group">
                                <label for="password" class="text-info"><span
                                        style="font-size:30px">Password:</span></label><br>
                                <input type="password" name="password" id="password" autocomplete="off"
                                    class="form-control" placeholder="********">
                            </div>
                            <div class="form-group text-center">
                                <label for="remember-me" class="text-info"></label><br>
                                <input type="submit" name="submit" class=" btn-lg"
                                    style="background-color: lightgrey; border:2px solid black" value="Submit">
                            </div>

                            <br>

                            <div id="register-link" class="text-center">
                                <h4><b>Not having an account??</b></h4>
                                <a href="http://localhost/assignment-3/index.php" class="text-info">
                                    <div class="mt-4 pt-2 text-center">
                                        <input style="background-color: lightgrey; border:3px solid black"
                                            class="btn btn-lg " type="login" id="login" name="login" value="Register" />
                                </a>
                            </div>
                    </div>
                    <br><br>








                    </form>
                </div>
            </div>
        </div>
    </div>
    </div>


    <?php

 if (isset($_POST['submit'])) {
     $email = $_POST['email'];
     $password = $_POST['password'];

     $sql_query = "select *from users where email = '" . $email . "' and password = '" . $password . "'";
     $result = mysqli_query($conn, $sql_query);
     $row = mysqli_num_rows($result);
     // echo $row;
     if ($row == 1) {
         $_SESSION['email'] = $email;
         header('location:display.php');
     } else {
 ?>
    <script>alert('E-mail Id or Password wrong')</script>
    <?php
     }
 }




 ?>