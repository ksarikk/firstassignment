<?php
include 'conn.php';


session_start();
$email1 = $_SESSION['email'];
if ($email1 == true) {

} else {
    header('location:login.php');
}

?>




<br><br>
<table border="1px" cellspacing="0" cellpadding="10px">

    <tr>
        <th>ID</th>
        <th>First_Name</th>
        <th>Last_Name</th>
        <th>Email</th>
        <th>Phone Number</th>
        <th>Password</th>
        <th>Gender</th>
        <th>Created Date</th>
     
    </tr>
    </thead>
    <?php
  $id = $_GET['id'];
  $select = "SELECT * FROM users WHERE id = '$id'";
  $data = mysqli_query($conn, $select);
  $result = mysqli_num_rows($data);
  if ($result) {
      while ($row = mysqli_fetch_array($data)) {
  ?>
    <tr>
        <td>
            <?php echo $row['id']; ?>
        </td>
        <td>
            <?php echo $row['first_name']; ?>
        </td>
        <td>
            <?php echo $row['last_name']; ?>
        </td>
        <td>
            <?php echo $row['email']; ?>
        </td>
        <td>
            <?php echo $row['phone_number']; ?>
        </td>
        <td>
            <?php echo $row['password']; ?>
        </td>
        <td>
            <?php echo $row['gender']; ?>
        </td>
        <td>
            <?php echo $row['created_date']; ?>
        </td>
       


    </tr>
    <?php
      }
  }
            ?>

</table>

<br>

<a href="display.php" style="background-color:lightgrey; width:100px; font-size:20px;">Back</a>
<a href="logout.php" style="background-color:lightgrey; width:100px; font-size:20px;">Logout</a>
<html>

<head>
</head>

<body style="background-color: lightcyan;">

</body>

</html>