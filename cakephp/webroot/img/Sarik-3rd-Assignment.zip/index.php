<?php
include 'reg.php';
?>

<!DOCTYPE html>
<html>

<head>

  <title>Registration Form</title>
  <script src="https://code.jquery.com/jquery-3.6.1.js" integrity="sha256-3zlB5s2uwoUzrXK3BT7AX3Fyvo`jsraNFxCc2vC/7pNI="
    crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.5/jquery.validate.min.js"
    integrity="sha512-rstIgDs0xPgmG6RX1Aba4KV5cWJbAMcvRCVmglpam9SoHZiUCyQVDdH2LPlxoHtrv17XWblE/V/PP+Tr04hbtA=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.5/additional-methods.min.js"
    integrity="sha512-6S5LYNn3ZJCIm0f9L6BCerqFlQ4f5MwNKq+EthDXabtaJvg3TuFLhpno9pcm+5Ynm6jdA9xfpQoMz2fcjVMk9g=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>

  <meta charset="UTF-8">
  <link rel="stylesheet" href="./css/style.css">

  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3"
    crossorigin="anonymous"></script>
  <script src="https://kit.fontawesome.com/05cad89e36.js" crossorigin="anonymous"></script>
  <script src="./js/assign.js"></script>
</head>

<body>


  <section class="vh-100 gradient-custom">
    <div class="container py-5 h-100">
      <div class="row justify-content-center align-items-center h-100">
        <div class="col-12 col-lg-9 col-xl-7">
          <div class="card shadow-2-strong card-registration" style="border-radius: 15px;">
            <div class="card-body p-4 p-md-5">
              <form id="form" action="" method="post">
                <h3 class="mb-4 pb-2 pb-md-0 mb-md-5 text-center"><b>
                    <marquee behavior=alternate>R E G I S T R A T I O N - F O R M</marquee>
                  </b></h3>

                <div class="row">
                  <div class="col-md-6 mb-4">


                    <div class="form-outline">
                      <label class="form-label" for="firstName">First Name</label><span class="error">&nbsp;*
                        <?php echo $error_fn; ?>
                      </span>

                      <input type="text" id="firstName" name="first_name" class="form-control form-control-lg"
                        placeholder="First Name" value="<?php echo $FirstName; ?>" />
                    </div>

                  </div>
                  <div class="col-md-6 mb-4">

                    <div class="form-outline">
                      <label class="form-label" for="last_name">Last Name</label><span class="error">&nbsp;*
                        <?php echo $error_ln; ?>

                        <input type="text" id="lastName" name="last_name" class="form-control form-control-lg"
                          placeholder="Last Name" value="<?php echo $LastName; ?>" />
                    </div>

                  </div>
                </div>

                <div class="row">
                  <div class="col-md-6 mb-4">

                    <div class="form-outline">
                      <label class="form-label" for="firstName">Email</label><span class="error">&nbsp;*
                        <?php echo $error_em; ?>

                        <input type="email" id="email" name="email" class="form-control form-control-lg"
                          placeholder="abc@gmail.com" value="<?php echo $Email; ?>" />
                    </div>

                  </div>
                  <div class="col-md-6 mb-4">

                    <div class="form-outline">
                      <label class="form-label" for="lastName">Phone No.</label><span class="error"><span
                          class="error">&nbsp;*
                          <?php echo $error_phone; ?>

                          <input type="text" id="phone" name="phone" class="form-control form-control-lg"
                            placeholder="9999999999" maxlength="10" value="<?php echo $PhoneNumber; ?>">
                    </div>


                  </div>
                </div>





                <div class="row">
                  <div class="col-md-6 mb-4">

                    <div class="form-outline">



                      <label class="form-label" for="password">Password</label><span class="error">&nbsp;*
                        <?php echo $error_pass; ?>
                        <input type="password" id="password" name="password" class="form-control form-control-lg" placeholder="********" minlength="5" value="<?php echo $Password; ?>" />
                    </div>

                  </div>
                  <div class="col-md-6 mb-4">

                    <div class="form-outline">
                      <label class="form-label" for="confirm">Confirm Password </label><span class="error">&nbsp;*
                        <?php echo $error_confirm; ?>

                        <input type="password" id="confirm" name="confirm" class="form-control form-control-lg"
                          placeholder="********" value="<?php echo $confirm
                          ; ?>" />
                    </div>


                  </div>
                </div>







                <div class="d-md-flex justify-content-start align-items-center mb-4 py-2">

                  <h6 class="mb-0 me-4  text-center">Gender: </h6>

                  <div class="form-check form-check-inline mb-0 me-4">
                    <input class="form-check-input" type="radio" name="gender" id="gender" value="male" />
                    <label class="form-check-label" for="maleGender">Male</label>
                  </div>


                  <div class="form-check form-check-inline mb-0 me-4">
                    <input class="form-check-input" type="radio" name="gender" id="gender" value="female" />
                    <label class="form-check-label" for="femaleGender">Female</label><span class="error">&nbsp;*
                      <?php echo $error_gender; ?>

                  </div>

                </div>
                <p class="gender1"></p>


                <div class="mt-4 pt-2 text-center">
                  <input class="btn btn-success btn-lg" type="submit" id="submit" name="submit" value="Submit" />

                  <br><br>
                  <div id="register-link" class="text-right">
                    <h4><b>Already having an account??</b></h4>
                    <a href="http://localhost/assignment-3/login.php" class="text-info">
                      <div class="mt-4 pt-2 text-center">
                        <input class="btn btn-success btn-lg" type="login" id="login" name="login" value="Login" />
                    </a>
                  </div>
                </div>

              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</body>

</html>