$(document).ready(function(){
    jQuery.validator.addMethod("regex", function(value, element, param) { return value.match(new RegExp("^" + param + "$")); });
    var ALPHA_REGEX = "[a-zA-Z]*";
$('#form').validate({
rules:{

    first_name:{
        regex: ALPHA_REGEX,
        required:true,
    },
    last_name:{
        regex: ALPHA_REGEX,
        required:true,
    },
    email:{
        required:true,
    },
    phone:{
        required:true,
        minlength: 10,
        digits:true,
    },
    password:{
        required:true,
    },
    confirm:{
        required:true,
        equalTo: "#password",
    },
    gender:{
        required:true,
    }
},
    messages:{
        first_name:{
            required:"Enter First Name",
            regex : "Please enter characters only",
        },
        last_name:{
            required:"Enter Last name",
        },
        email:{
            required:"Enter Email",
        },
        phone:{
            required:"Enter Phone",
            maxlength:"Enter Phone Number in 10 digits",
        },
        password:{
            required:"Enter Password",
        },
        confirm:{
            required:"Enter Password",
            equalTo: "Password do not match",
        },
        gender:{
            required:"Select Gender"
        }
    },
    errorPlacement:function(error,element)
    {
        if(element.is(":radio"))
        {
            error.appendTo('.gender1');
        
        }
            else{
                error.insertAfter(element);
                
            }
    }
});
});