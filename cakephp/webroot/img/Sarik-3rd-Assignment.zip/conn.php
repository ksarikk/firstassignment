<?php
$host="localhost";
$uname="root";
$pass="password";
$db="asssignment3";

$conn=mysqli_connect($host,$uname,$pass,$db);

if ($conn) {
    // echo "connected";
}
else {
    echo "not connected";
}
?>